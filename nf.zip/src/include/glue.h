#ifndef GLUE_H
#define GLUE_H

void glue_display( lua_State *l );
void glue_rsrc( lua_State *l );
void glue_event( lua_State *l );

#endif