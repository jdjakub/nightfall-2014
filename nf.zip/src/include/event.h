#ifndef EVENT_H
#define EVENT_H
#include "core.h"

void EVT_poll_and_handle_usr_evts( int *keepRunning );

#endif