#ifndef GLUE_DISPLAY_AUX_H
#define GLUE_DISPLAY_AUX_H
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include "ui_cmpts.h"
#define UDATA_FUNC(func) udata_##func( 

static void type_check( lua_State *l, UI_cmpt_type type)
{
	luaL_argcheck( l, type < UI_LAST, 1, "invalid component type" );
}

static void set_field_int( lua_State *l, const char *kname, int val )
{
	lua_pushinteger( l, val );
	lua_setfield( l, -2, kname );
}

static void set_field_bool( lua_State *l, const char *kname, int val )
{
	lua_pushboolean( l, val );
	lua_setfield( l, -2, kname );
}


#endif