#ifndef LOGIC_H
#define LOGIC_H

void LGC_init( void );
void LGC_begin( void );

#endif