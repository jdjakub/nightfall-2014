#ifndef UI_H
#define UI_H
#include <SDL2/SDL.h>
#include "core.h"
#include "ui_cmpts.h"

void UI_init( SDL_Renderer *rnd );
void UI_cleanup( void );

void UI_push_screen( void );
struct cmpt_list *UI_get_screen( int idx );
void UI_pop_screen( void );

void UI_draw_frame( int delta );

UI_cmpt_id UI_add_cmpt( int scrIdx, UI_cmpt_type type, int layer );
void UI_del_cmpt( UI_cmpt_id id );

struct cmpt_node *UI_find_closest_containing( SDL_Point p );

#endif