#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "include/core.h"
#include "include/ui.h"
#include "include/uidata.h"
#include "include/display.h"

static struct screen_stack screens;
static SDL_Renderer *rnd = NULL;

void fill_func_lists( void );

void UI_init( SDL_Renderer *r )
{
	screens.top = -1;
	rnd = r;
	fill_func_lists();
}

void UI_cleanup( void )
{
	while ( screens.top != -1 ) {
		UI_pop_screen();
	}
}

void UI_push_screen( void )
{
	scr_stack_push( &screens );
	printf( "Pushed new screen to screen stack. top=%d\n", screens.top );
}

struct cmpt_list *UI_get_screen( int idx )
{
	return scr_stack_get( &screens, idx );
}

void UI_pop_screen( void )
{
	if ( screens.top > -1 ) {
		struct cmpt_list *scr = scr_stack_pop( &screens );
		del_cmpts( (struct cmpt_node*) scr );
		printf( "Popped and freed screen from screen stack. top=%d\n", screens.top );
	}
}

void UI_draw_frame( int delta )
{
	struct cmpt_node *curr = scr_stack_top( &screens )->first;
	
	while ( curr ) {
		if ( curr->visible ) {
			//printf( "Drawing cmpt #%u! (%d)\n", curr->id, curr->layer );
			cmpt_funcs[curr->type].draw( curr, rnd );
		}
		curr = curr->next;
	}
}

UI_cmpt_id UI_add_cmpt( int scrIdx, UI_cmpt_type type, int layer )
{
	struct cmpt_node *cmpt = new_cmpt( type, layer );
	
	if ( !cmpt ) {
		return 0;
	} else {
		struct cmpt_list *curr_scr = scr_stack_top( &screens );
		
		insert_layer_sorted( curr_scr, cmpt );
		return cmpt->id;
	}
}

void UI_del_cmpt( UI_cmpt_id id )
{
	struct cmpt_list *scr = scr_stack_top( &screens );
	struct cmpt_node *c = NULL;
	
	for ( c=scr->first; c!=NULL; c=c->next ) {
		if ( c->id == id ) {
			del_cmpt( remove_cmpt( scr, c ) );
			printf( "Deleted component #%u", id );
			return;
		}
	}
}

struct cmpt_node *UI_find_closest_containing( SDL_Point p )
{
	struct cmpt_list *l = scr_stack_top( &screens );
	struct cmpt_node *c = l->last;
	
	/* Now traverse backwards until finding an intersection */
	while ( c ) {
		if ( SDL_EnclosePoints( &p, 1, &c->bounds, NULL ) ) {
			return c;
		} else if ( c == l->first ) {
			break;
		} else {
			c = c->prev;
		}
	}
	return NULL;
}