#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "include/glue_display.h"
#include "include/display.h"
#include "include/ui.h"
#include "include/uidata.h"

static struct cmpt_node *get_set_base( lua_State *l )
{
	/* Stack:
	 * 3 Table of data [?]
	 * 2 ID
	 * 1 Screen Index
	*/
	int scrIdx;
	UI_cmpt_id id;
	struct cmpt_list *scr;
	struct cmpt_node *comp;
	
	scrIdx = luaL_checkinteger( l, 1 );
	id = luaL_checkinteger( l, 2 );
	scr = UI_get_screen( scrIdx );
	comp = find_cmpt( scr->first, id );
	luaL_argcheck( l, comp, 2, "no such component" );
	
	return comp;
}

static void fill_rect( lua_State *l, SDL_Rect *r, int tableIndex )
{
	lua_getfield( l, tableIndex, "x" );
	if ( lua_isnumber( l, -1 ) ) {
		r->x = lua_tointeger( l, -1 );
	}
	lua_getfield( l, tableIndex, "y" );
	if ( lua_isnumber( l, -1 ) ) {
		r->y = lua_tointeger( l, -1 );
	}
	lua_getfield( l, tableIndex, "w" );
	if ( lua_isnumber( l, -1 ) ) {
		r->w = lua_tointeger( l, -1 );
	}
	lua_getfield( l, tableIndex, "h" );
	if ( lua_isnumber( l, -1 ) ) {
		r->h = lua_tointeger( l, -1 );
	}
}

LUA_GLUE( pushScreen )
{
	UI_push_screen();
	return 0;
}

LUA_GLUE( popScreen )
{
	UI_pop_screen();
	return 0;
}

LUA_GLUE( addComponent ) /* screen, type, layer */
{
	UI_cmpt_type type;
	int layer, id;
	int scrIdx;
	
	scrIdx = luL_checkinteger( l, 1 );
	type = luaL_checkinteger( l, 2 );
	layer = luaL_checkinteger( l, 3 );
	luaL_argcheck( l, type < UI_LAST, 1, "invalid component type" );
	
	id = UI_add_cmpt( type, layer );
	
	lua_pushinteger( l, id );
	return 1;
}

LUA_GLUE( deleteComponent ) /* screen, id */
{
	
}

LUA_GLUE( getCmptBaseData ) /* screen, id */
{
	struct cmpt_node c = { 0 };
	struct cmpt_node *comp = get_set_base( l );
	/* Need to send back type, id, groupId, layer, visible, bounds */
	cmpt_get_data( comp, &c );
	lua_createtable( l, 0, 6 );
	set_field_int( l, "type", c.type );
	set_field_int( l, "id", c.id );
	set_field_int( l, "groupId", c.group_id );
	set_field_int( l, "layer", c.layer );
	set_field_bool( l, "visible", c.visible );
	set_field_int( l, "x", c.bounds.x );
	set_field_int( l, "y", c.bounds.y );
	set_field_int( l, "w", c.bounds.w );
	set_field_int( l, "h", c.bounds.h );
	
	return 1;
}

LUA_GLUE( setCmptBaseData ) /* screen, id, data */
{
	struct cmpt_node c = { 0 };
	struct cmpt_node *comp = get_set_base( l );
	
	cmpt_get_data( comp, &c );
	luaL_checktype( l, 3, LUA_TTABLE);
	
	lua_getfield( l, 3, "groupId" );
	if ( lua_isnumber( l, -1 ) ) {
		c.group_id = lua_tointeger( l, -1 );
	}
	lua_getfield( l, 3, "visible" );
	if ( lua_isboolean( l, -1 ) ) {
		c.visible = lua_toboolean( l, -1 );
	}
	fill_rect( l, &c.bounds, 3 );
	
	cmpt_set_data( comp, &c );
	
	return 0;
}

LUA_GLUE( getCmptUserData ) /* screen, id */
{
	struct cmpt_node *comp = get_set_base( l );
	return cmpt_funcs[comp->type].udata_get( l, comp );
}

LUA_GLUE( setCmptUserData ) /* screen, id, data */
{
	struct cmpt_node *comp = get_set_base( l );
	return cmpt_funcs[comp->type].udata_set( l, comp );
}

LUA_GLUE( getTextureDims ) /* tex */
{
	SDL_Texture *tex = check_data( l, 1 );
	int w, h;
	
	SDL_QueryTexture( tex, NULL, NULL, &w, &h );
	lua_pushinteger( l, w );
	lua_pushinteger( l, h );
	
	return 2;
}

LUA_GLUE( createGlyphAtlas ) /* fontData, size, pxSize */
{
	void *data = check_data( l, 1 );
	size_t size = luaL_checkinteger( l, 2 );
	size_t px_size = luaL_checkinteger( l, 3 );
	struct DSP_glyph_atlas *atlas = DSP_create_glyph_atlas( data, size, px_size );
	
	if ( atlas ) {
		lua_pushlightuserdata( l, atlas );
		return 1;
	} else {
		luaL_error( l, "Couldn't create glyph atlas" );
		return 0;
	}
}

/*LUA_GLUE( getTextDims ); /* atlas, str 
{
	struct DSP_glyph_atlas *atlas = check_data( l );
	const char *str = luaL_checkstring( l, 2 );
	int w, h;
	
	DSP_get_text_dims( atlas, str, &w, &h );
	
	lua_pushinteger( l, w );
	lua_pushinteger( l, h );
	return 2;
}*/

LUA_GLUE( createSurface ) /* w, h */
{
	unsigned w = luaL_checkinteger( l, 1 );
	unsigned h = luaL_checkinteger( l, 2 );
	SDL_Surface *surf = DSP_create_rgba_surf( w, h );
	
	if ( surf ) {
		lua_pushlightuserdata( l, surf );
		return 1;
	} else {
		luaL_error( l, "Could not create surface." );
		return 0;
	}
}

LUA_GLUE( createTexture ) /* surf */
{
	SDL_Surface *surf = check_data( l, 1 );
	SDL_Texture *tex = DSP_tex_from_surf( surf );
	
	if ( tex ) {
		lua_pushlightuserdata( l, tex );
		return 1;
	} else {
		luaL_error( l, "Could not create texture from surface." );
		return 0;
	}
}

LUA_GLUE( freeSurface ) /* surf */
{
	SDL_Surface *surf = check_data( l, 1 );
	
	SDL_FreeSurface( surf );
	return 0;
}

LUA_GLUE( updateTexture ) /* tex, surf */
{
	SDL_Texture *tex = check_data( l, 1 );
	SDL_Surface *surf = check_data( l, 2 );
	
	SDL_SaveBMP( surf, "surface.bmp" );
	SDL_UpdateTexture( tex, NULL, surf->pixels, surf->pitch );
	return 0;
}

LUA_GLUE( drawText ) /* atlas, surf, str, bounds */
{
	struct DSP_glyph_atlas *atlas = check_data( l, 1 );
	SDL_Surface *surf = check_data( l, 2 );
	const char *str = luaL_checkstring( l, 3 );
	SDL_Rect bounds = { 0 };
	
	luaL_argcheck( l, str[1] != '\0', 3, "str cannot be empty" );
	
	luaL_checktype( l, 4, LUA_TTABLE );
	fill_rect( l, &bounds, 4 );
	
	luaL_argcheck( l, bounds.w > 0, 4, "text width cannot be 0" );
	
	DSP_draw_text( atlas, surf, str, &bounds );
	
	lua_pushinteger( l, bounds.h );
	return 1;
}