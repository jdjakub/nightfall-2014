print("AND SO IT BEGINS...")
--[[comps = {}
numComps = 10
data = {
	visible = true
}
for i=1,numComps do
	comps[i] = Display.addComponent(Display.CT_SPRITE, numComps-i)
	Display.setCmptBaseData(-1, comps[i], data)
end
udata = {sx=3, sy=1, sw=4, sh=1}
Display.setCmptUserData(-1, comps[numComps], udata)
udata = Display.getCmptUserData(-1, comps[numComps])
for k,v in pairs(udata) do
	print(k, "=", v)
end
]]--

local scr = Display.newScreen()
Display.setScreen(0, scr)
Display.setSettings({fullscreen=true, w=800, h=600})

local fdata, dsize = Rsrc.getRawResourceData(Rsrc.MAIN, "TerminalVector.ttf")
local atlas = Display.createGlyphAtlas(fdata, dsize, 16)
Rsrc.freeRawResourceData(fdata)
local texRed = Rsrc.getTexture(Rsrc.MAIN, "backg_red.png")
local texBin = Rsrc.getTexture(Rsrc.MAIN, "backg_binary.png")
local str = "Why is text so complicated??\nI'm going to type the pathological chars %/ETZ\\z THIS_IS_A_TEST_OF_WHAT_LOOKS_LIKE_A_REALLY_LONG_CONSTANT_TO_SEE_HOW_MY_BEAUTIFUL_TEXT_RENDERER_HANDLES_REALLY_LONG_LINES. Here are some more words to test the word wrapping capabilities. They are anispeptic, frasmotic and even compunctuous to have caused you such pericombobulations. Despite this font being monospaced it should work equally well with other fonts. And, of course...\n\nLorem ipsum dolor sit amet. Consecetur adpiscing elit etc etc etc.\n"
local textSurf = Display.createSurface(800, 600)
local texText = Display.createTexture(textSurf)

local textBounds1 = {x=32,y=32,w=300}
textBounds1.h = Display.drawText(atlas, textSurf, str, textBounds1)
Display.updateTexture(texText, textSurf)

local text1 = Display.addComponent(scr, Display.CT_SPRITE, 5)
textBounds1.visible = true;
Display.setCmptBaseData(scr, text1, textBounds1)
Display.setCmptUserData(scr, text1, {
	tex = texText, col = col1,
	sx = textBounds1.x, sy = textBounds1.y,
	sw = textBounds1.w, sh = textBounds1.h,
	r = 0, g = 255, b = 0, a = 127 
})

local backg = Display.addComponent(scr, Display.CT_SPRITE, 0)
Display.setCmptBaseData(scr, backg, {
	visible = true,
	x = 0, y = 0,
	w = 800, h = 600
})
Display.setCmptUserData(scr, backg, {
	tex = texBin,
	sx = 0 , sy = 0,
	sw = 800, sh = 600
})

local spr = Display.addComponent(scr, Display.CT_SPRITE, 1)
Display.setCmptBaseData(scr, spr, {
	visible = true,
	x = 400, y = 64,
	w = 300, h = 500
})
Display.setCmptUserData(scr, spr, {
	tex = texRed,
	sx = 0 , sy = 0,
	sw = 300, sh = 500
})