#include <SDL2/SDL.h>
#include "include/core.h"
#include "include/rsrc.h"

struct RES_node {
	const RES_id id;
	RES_type type;
	unsigned refs;
	void *data;
	struct RES_node *next;
};

static struct RES_node *res_list = NULL;
static unsigned bytes_used = 0;

static void del_all_rsrcs( void );
int cmp_res_ids( const RES_id a, const RES_id b );

void RES_init( void )
{
}

void RES_cleanup( void )
{
	del_all_rsrcs();
}

int RES_load( const RES_id id, RES_type type )
{
	RES_node **curr_addr = &res_list;
	
	while ( *curr_addr ) {
		RES_node *curr = *curr_addr;
		int result = cmp_res_ids( id, curr->id );
		
		if ( result == 0 ) {
			return load_rsrc( curr );
		}
	}
}

void RES_acquire( const RES_id id )
{
}

void RES_release( const RES_id id )
{
}

unsigned RES_get_byte_count( const RES_id id )
{
}

void *RES_get_raw_data( const RES_id id )
{
}

bstring RES_get_copy_as_string( const RES_id id )
{
}

/*bstring RES_load_as_text( const char *name )
{	
	FILE *f = fopen( name,  "r" );
	size_t actual_size = 0;
	char *str = NULL;
	int n;
	bstring b = NULL;
	if ( f ) {
		size_t size = get_file_size( f );
		str = malloc( sizeof( char ) * size + 1); /* Dynalloc memory for chars in file plus \0 
		
		if ( str ) {
			/* Read entirety of file into memory
			actual_size = fread( (void*) str, sizeof( char ), size, f );
			str[actual_size] = '\0'; /* Set null terminator
			
			/* Fill bstring
			b = bfromcstr( str );
			free( str );
		}
		fclose( f );
	}
	return b;
}

static size_t get_file_size( FILE *f ) {
	size_t size;
	
	fseek( f, 0, SEEK_END );
	size = ftell( f );
	fseek( f, 0, SEEK_SET );
	
	return size;
}
*/