#ifndef RSRC_H
#define RSRC_H
#include "core.h"

typedef bstring RES_id;

typedef enum {
	RES_DATAFILE,
	RES_SCRIPT,
	RES_TEXTURE,
} RES_type;

void RES_init( void );
void RES_cleanup( void );

int RES_load( const RES_id id, RES_type type );
void RES_acquire( const RES_id id );
void RES_release( const RES_id id );
unsigned RES_get_byte_count( const RES_id id );

void *RES_get_raw_data( const RES_id id );
bstring RES_get_copy_as_string( const RES_id id );


#endif