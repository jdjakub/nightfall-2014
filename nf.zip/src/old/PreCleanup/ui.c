#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "include/core.h"
#include "include/ui.h"
#include "include/uidata.h"
#include "include/display.h"

static struct screen_stack screens;
static SDL_Renderer *rnd = NULL;

void fill_func_lists( void );
static cmpt_list get_screen( int idx );

void UI_init( SDL_Renderer *r )
{
	screens.top = -1;
	rnd = r;
	fill_func_lists();
}

void UI_cleanup( void )
{
	while ( screens.top != -1 ) {
		UI_pop_screen();
	}
}

void UI_push_screen( void )
{
	scr_stack_push( &screens, NULL );
	printf( "Pushed new screen to screen stack. top=%d\n", screens.top );
}

cmpt_list UI_get_screen( int idx )
{
	return scr_stack_get( &screens, idx );
}

void UI_pop_screen( void )
{
	if ( screens.top > -1 ) {
		cmpt_list scr = scr_stack_pop( &screens );
		del_cmpts( &scr );
		printf( "Popped and freed screen from screen stack. top=%d\n", screens.top );
	}
}

void UI_draw_frame( int delta )
{
	struct cmpt_node *curr = scr_stack_top( &screens );
	
	while ( curr ) {
		if ( curr->visible ) {
			//printf( "Drawing cmpt #%d! (%d)\n", curr->id, curr->layer );
			cmpt_funcs[curr->type].draw( curr, rnd );
		}
		curr = curr->next;
	}
}

UI_cmpt_id UI_add_cmpt( UI_cmpt_type type, int layer )
{
	struct cmpt_node *cmpt = new_cmpt( type, layer );
	
	if ( !cmpt ) {
		return 0;
	} else {
		cmpt_list *curr_scr = &screens.items[screens.top];
		
		insert_layer_sorted( curr_scr, cmpt );
		return cmpt->id;
	}
}

void UI_del_cmpt( UI_cmpt_id id )
{
	cmpt_list *scr = &screens.items[screens.top];
	struct cmpt_node *c = NULL;
	
	for ( c=*scr; c!=NULL; c=c->next ) {
		if ( c->id == id ) {
			del_cmpt( remove_cmpt( scr ) );
			return;
		} else {
			scr = &c->next;
		}
	}
}

void UI_msg_cmpt( struct cmpt_node *c, UI_msg msg, void *data )
{
	switch ( msg ) {
		case UIM_GET_DATA: { /* data = cmpt_node* */
			struct cmpt_node *d = (struct cmpt_node*) data;
			
			d->type = c->type;
			d->id = c->id;
			d->group_id = c->group_id;
			d->layer = c->layer;
			d->visible = c->visible;
			memcpy( &d->bounds, &c->bounds, sizeof( d->bounds ) );
			break;
		}
		case UIM_SET_DATA: { /* data = cmpt_node* */
			struct cmpt_node *d = (struct cmpt_node*) data;
			
			/* Going to copy except for id, type, layer, user_data */
			c->group_id = d->group_id;
			c->visible = d->visible;
			memcpy( &c->bounds, &d->bounds, sizeof( d->bounds ) );
			break;
		}
		default:
			cmpt_funcs[c->type].msg( c, msg, data );
			break;
	}
}