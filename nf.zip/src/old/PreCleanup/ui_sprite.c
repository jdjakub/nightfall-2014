#include <SDL2/SDL.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include "include/ui.h"
#include "include/ui_udata.h"

void sprite_init( struct cmpt_node *c )
{
	struct sprite_data *d = (struct sprite_data*) COR_alloc( sizeof( *d ), 1 );
	
	memset( (void*) d, 0, sizeof( *d ) );
	c->user_data = d;
}

void sprite_draw( struct cmpt_node *c, SDL_Renderer *r )
{
	struct sprite_data *d = (struct sprite_data*) c->user_data;
	
	if ( d->tex ) {
		SDL_RenderCopy( r, d->tex, &d->src,  &c->bounds );
	}
	//printf( "SRC: %d,%d,%d,%d\n", d->src.x, d->src.y, d->src.w, d->src.h );
	//printf( "DST: %d,%d,%d,%d\n", c->bounds.x, c->bounds.y, c->bounds.w, c->bounds.h );
}

void sprite_free( struct cmpt_node *c )
{
	COR_free( (void*) c->user_data );
}

void sprite_msg( struct cmpt_node *c, UI_msg msg, void *data )
{
	struct sprite_data *d = (struct sprite_data*) c->user_data;
	
	switch ( msg ) {
		case UIM_GET_DATA:
			break;
		case UIM_SET_UDATA: { /* data = sprite_data* */
			memcpy( d, data, sizeof( *d ) );
			break;
		}
	}
}

int sprite_dispatch( lua_State *l, struct cmpt_node *c, UI_msg msg )
{
	/* Stack:
	 * 4 Table of data [?]
	 * 3 Message
	 * 2 ID
	 * 1 Screen Index
	*/
	switch ( msg ) {
		case UIM_GET_UDATA: {
				struct sprite_data d = { 0 };
				
				memcpy( &d, &c->user_data, sizeof( d ) );
				lua_push
				break;
			}
		case UIM_SET_UDATA: {
				
				break;
			}
		default:
			return 0;
	}
}