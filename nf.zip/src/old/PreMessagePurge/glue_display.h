#ifndef GLUE_DISPLAY_H
#define GLUE_DISPLAY_H
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#define LUA_GLUE(func) int glue_##func( lua_State *l )

LUA_GLUE( pushScreen );
LUA_GLUE( popScreen );
LUA_GLUE( addComponent ); /* type, layer */
LUA_GLUE( sendMessage ); /* screen, id, msg, ... */

#endif