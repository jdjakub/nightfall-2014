#include "include/glue_display.h"
#include "include/glue_aux.h"
#include "include/ui.h"
#include "include/uidata.h"

static void type_check( lua_State *l, UI_cmpt_type type)
{
	luaL_argcheck( l, type < UI_LAST, 1, "invalid component type" );
}

LUA_GLUE( pushScreen )
{
	UI_push_screen();
	return 0;
}

LUA_GLUE( popScreen )
{
	UI_pop_screen();
	return 0;
}

LUA_GLUE( addComponent ) /* type, layer */
{
	UI_cmpt_type type;
	int layer, id;
	
	type = luaL_checkinteger( l, 1 );
	layer = luaL_checkinteger( l, 2 );
	type_check( l, type );
	
	id = UI_add_cmpt( type, layer );
	
	lua_pushinteger( l, id );
	return 1;
}

LUA_GLUE( sendMessage ) /* screen, id, msg, ... */
{
	int scrIdx;
	UI_cmpt_id id;
	UI_msg msg;
	cmpt_list scr;
	struct cmpt_node *comp;
	
	scrIdx = luaL_checkinteger( l, 1 );
	id = luaL_checkinteger( l, 2 );
	msg = luaL_checkinteger( l, 3 );
	printf("Processing message: %d %d %d\n", scrIdx, id, msg);
	scr = UI_get_screen( scrIdx );
	comp = find_cmpt( scr, id );
	luaL_argcheck( l, comp, 2, "no such component" );
	
	switch ( msg ) {
		case UIM_GET_DATA: {
			struct cmpt_node c = { 0 };
			/* Need to send back type, id, groupId, layer, visible, bounds */
			cmpt_get_data( comp, &c );
			lua_createtable( l, 0, 6 );
			set_field_int( l, "type", c.type );
			set_field_int( l, "id", c.id );
			set_field_int( l, "groupId", c.group_id );
			set_field_int( l, "layer", c.layer );
			set_field_bool( l, "visible", c.visible );
			set_field_int( l, "x", c.bounds.x );
			set_field_int( l, "y", c.bounds.y );
			set_field_int( l, "w", c.bounds.w );
			set_field_int( l, "h", c.bounds.h );
			
			return 1;
			break;
		}
		case UIM_SET_DATA: {
			struct cmpt_node c = { 0 };
			
			cmpt_get_data( comp, &c );
			luaL_checktype( l, 4, LUA_TTABLE);
			
			lua_getfield( l, 4, "groupId" );
			if ( lua_isnumber( l, -1 ) ) {
				c.group_id = lua_tointeger( l, -1 );
			}
			lua_getfield( l, 4, "visible" );
			if ( lua_isboolean( l, -1 ) ) {
				c.visible = lua_toboolean( l, -1 );
			}
			lua_getfield( l, 4, "x" );
			if ( lua_isnumber( l, -1 ) ) {
				c.bounds.x = lua_tointeger( l, -1 );
			}
			lua_getfield( l, 4, "y" );
			if ( lua_isnumber( l, -1 ) ) {
				c.bounds.y = lua_tointeger( l, -1 );
			}
			lua_getfield( l, 4, "w" );
			if ( lua_isnumber( l, -1 ) ) {
				c.bounds.w = lua_tointeger( l, -1 );
			}
			lua_getfield( l, 4, "h" );
			if ( lua_isnumber( l, -1 ) ) {
				c.bounds.h = lua_tointeger( l, -1 );
			}
			lua_pop( l, 6 );
			
			cmpt_set_data( comp, &c );
			
			return 0;
			break;
		}
		default:
			return cmpt_funcs[comp->type].msg( l, comp, msg );
			break;
	}
}