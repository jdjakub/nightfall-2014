#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include "include/glue.h"
#include "include/glue_display.h"
/*#include "glue_event.h"*/

static const luaL_reg display_exports[] =
{
	{"pushScreen", glue_pushScreen},
	{"popScreen", glue_popScreen},
	{"addComponent", glue_addComponent},
	{"sendMessage", glue_sendMessage},
	{0, 0}
};

static const luaL_reg event_exports[] =
{
	{0, 0}
};

void glue_display( lua_State *l )
{
	lua_getglobal( l, "Display" );
	luaL_register( l, NULL, display_exports );
	lua_pop( l, 1 );
}

void glue_event( lua_State *l )
{
}