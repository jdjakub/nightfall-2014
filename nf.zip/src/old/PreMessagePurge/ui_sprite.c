#include <SDL2/SDL.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include "include/ui.h"
#include "include/glue_aux.h"

struct sprite_data {
	SDL_Texture *tex;
	SDL_Rect src;
};

void sprite_init( struct cmpt_node *c )
{
	struct sprite_data *d = (struct sprite_data*) COR_alloc( sizeof( *d ), 1 );
	
	memset( (void*) d, 0, sizeof( *d ) );
	c->user_data = d;
}

void sprite_draw( struct cmpt_node *c, SDL_Renderer *r )
{
	struct sprite_data *d = (struct sprite_data*) c->user_data;
	
	if ( d->tex ) {
		SDL_RenderCopy( r, d->tex, &d->src,  &c->bounds );
	}
	//printf( "SRC: %d,%d,%d,%d\n", d->src.x, d->src.y, d->src.w, d->src.h );
	//printf( "DST: %d,%d,%d,%d\n", c->bounds.x, c->bounds.y, c->bounds.w, c->bounds.h );
}

void sprite_free( struct cmpt_node *c )
{
	COR_free( (void*) c->user_data );
}

int sprite_msg( lua_State *l, struct cmpt_node *c, UI_msg msg )
{
	/* Stack:
	 * 4 Table of data [?]
	 * 3 Message
	 * 2 ID
	 * 1 Screen Index
	*/
	struct sprite_data *d = (struct sprite_data*) c->user_data;
	
	switch ( msg ) {
		case UIM_GET_UDATA: {
				lua_createtable( l, 0, 2 );
				lua_pushlightuserdata( l, d->tex );
				lua_setfield( l, -2, "tex" );
				set_field_int( l, "sx", d->src.x );
				set_field_int( l, "sy", d->src.y );
				set_field_int( l, "sw", d->src.w );
				set_field_int( l, "sh", d->src.h );
				return 1;
				break;
			}
		case UIM_SET_UDATA: {
				printf("I'm in your sprite_msg, handling your msg (UIM_SET_UDATA)\n");
				luaL_checktype( l, 4, LUA_TTABLE );
				lua_getfield( l, 4, "tex" );
				if ( lua_isuserdata( l, -1 ) ) {
					d->tex = (SDL_Texture*) lua_touserdata( l, -1 );
				}
				lua_getfield( l, 4, "sx" );
				if ( lua_isnumber( l, -1 ) ) {
					d->src.x = lua_tointeger( l, -1 );
				}
				lua_getfield( l, 4, "sy" );
				if ( lua_isnumber( l, -1 ) ) {
					d->src.y = lua_tointeger( l, -1 );
				}
				lua_getfield( l, 4, "sw" );
				if ( lua_isnumber( l, -1 ) ) {
					d->src.w = lua_tointeger( l, -1 );
				}
				lua_getfield( l, 4, "sh" );
				if ( lua_isnumber( l, -1 ) ) {
					d->src.h = lua_tointeger( l, -1 );
				}
				lua_pop( l, 5 );
				return 0;
				break;
			}
		default:
			return 0;
	}
}