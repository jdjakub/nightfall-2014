State.NETMAP = {}

function State.NETMAP:onEnter()
    print("-- NETMAP STATE ENTERED --")
end

function State.NETMAP:onLeave()
	print("-- NETMAP STATE LEFT --")
end