state = {
	state
}

function state:switchTo(newState)
	self.state:onLeave();
	self.state = newState;
	self.state:onEnter();
end

state.NETMAP = {
	onEnter = function(self)
		
	end

	onLeave = function(self)
	
	end,
}