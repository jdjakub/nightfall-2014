package.path = "./rsrc/scripts/?.lua;" .. package.path
require("display")
--require("event")
--require("rsrc")