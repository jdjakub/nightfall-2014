local P = {}
Rsrc = P
setmetatable(P, {__index = _G})
setfenv(1, P)