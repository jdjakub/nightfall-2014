local P = {}
Display = P
setmetatable(P, {__index = _G})
setfenv(1, P)
print("Hello, World! From display.lua")
MSG_GET_DATA = 1
MSG_SET_DATA = 2
MSG_GET_UDATA = 3
MSG_SET_UDATA = 4

CT_SPRITE = 0