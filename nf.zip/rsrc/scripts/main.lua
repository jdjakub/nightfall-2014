print("AND SO IT BEGINS...")
Display.pushScreen()

comps = {}
data = {visible = true}
for i=1,100 do
	comps[i] = Display.addComponent(Display.CT_SPRITE, 100-i)
	Display.sendMessage(-1, comps[i], Display.MSG_SET_DATA, data)
end