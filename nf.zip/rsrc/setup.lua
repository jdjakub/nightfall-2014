print("Setup running");

function nightfallMain()
	Rsrc.execScript(Rsrc.MAIN, "main.lua")
end