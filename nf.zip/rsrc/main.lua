print("AND SO IT BEGINS...")
Rsrc.execScript(Rsrc.MAIN, "state.lua")
Rsrc.execScript(Rsrc.MAIN, "stateHome.lua")
Rsrc.execScript(Rsrc.MAIN, "stateNetmap.lua")

State.switchTo(State.HOME)