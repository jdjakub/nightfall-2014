rsrc.DATA_PLAYER = "player.json";
rsrc.DATA_NETMAP = "netmap.json";

display.DIMS = {800, 600}
display.CLEAR_COL = {0xFF, 0x00, 0xFF, 0xFF}